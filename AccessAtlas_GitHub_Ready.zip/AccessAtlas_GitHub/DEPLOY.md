# Publish AccessAtlas

## GitHub

1. Sign into GitHub and create a new public repository named `accessatlas`.
2. Do not initialize it with a README, license, or `.gitignore` (they're included).
3. On your computer, extract the project ZIP and open a terminal in `AccessAtlas_GitHub`.
4. Run:

```bash
git init
git add .
git commit -m "Build AccessAtlas educational equity dashboard"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/accessatlas.git
git push -u origin main
```

Alternatively, upload the extracted files using **Add file → Upload files**, including hidden `.github` and `.gitignore` files. Preserve the nested folder structure.

## Streamlit Community Cloud (optional)

1. Sign in at https://share.streamlit.io/ with GitHub.
2. Create a new app using this GitHub repository.
3. Select branch `main` and entrypoint `app.py`.
4. Deploy. Dependencies are listed in `requirements.txt`.

No API key, database, or secrets required. Never upload real identifying student data to a public repository.
